import discord
from iBot import client


@client.event
async def on_raw_reaction_add(payload):
    pass
