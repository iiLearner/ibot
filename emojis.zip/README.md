### ibot
Discord bot to manage tournaments with anticheat and some other useful things.
Made with python and main dependency discordpy

https://discord.gg/79kbdEDwnV
